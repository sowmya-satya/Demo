package com.mindtree.collegemanagement.exception.util;

public class ErrorConstants {

	public static final String NOSUCHSTUDENTFOUND = "No Student is registered with 3 labs";
}
