package com.mindtree.collegemanagement.service.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.collegemanagement.entity.College;
import com.mindtree.collegemanagement.entity.Lab;
import com.mindtree.collegemanagement.entity.Student;
import com.mindtree.collegemanagement.exception.NoSuchStudentFound;
import com.mindtree.collegemanagement.exception.ServiceException;
import com.mindtree.collegemanagement.exception.util.ErrorConstants;
import com.mindtree.collegemanagement.repository.CollegeRepository;
import com.mindtree.collegemanagement.repository.LabRepository;
import com.mindtree.collegemanagement.repository.StudentRepository;
import com.mindtree.collegemanagement.service.CollegeService;

@Service
public class CollegeImpl implements CollegeService {

	@Autowired
	private CollegeRepository collegeRepository;
	@Autowired
	private LabRepository labRepository;

	@Autowired
	private StudentRepository studentRepository;

	public String addDetails(College college) {

		List<Student> student = new ArrayList<Student>();
		for (Lab l : college.getLabs()) {
			List<Student> students = l.getStudents();
			for (Student s : students) {
				List<Lab> labs = s.getLabs();
				s.setLabs(labs);
				student.add(s);
			}
			l.setStudents(student);
			l.setCollege(college);
		}
		collegeRepository.save(college);
		return "inserted successfully";
	}

	public List<Lab> getLabDetailsOnStudentDetails(int studentId) {

		Student student = studentRepository.findById(studentId).get();
		List<Lab> labDetails = student.getLabs();
		return labDetails;
	}

	public List<Student> getStudentDetailsForParticularLab(String labName) {

		Lab lab = labRepository.findBylabName(labName);
		List<Student> studentDetails = lab.getStudents();
		return studentDetails;
	}

	public List<Student> getStudentDetailsRegisteredForMoreThan3Labs() throws ServiceException {

		int count = 0;
		List<Student> studentDetails = studentRepository.findAll();
		List<Student> students = new ArrayList<Student>();
		for (Student s : studentDetails) {
			List<Lab> labDetails = s.getLabs();
			if (labDetails.size() >= 4) {
				count++;
				for (Lab l : labDetails) {
					students.addAll(l.getStudents());
				}
			}
		}
		if (count == 0) {
			try {
				throw new NoSuchStudentFound(ErrorConstants.NOSUCHSTUDENTFOUND);
			} catch (NoSuchStudentFound e) {
				throw new ServiceException(e.getMessage());
			}
		}
		return students;
	}

	@Override
	public String updateDetails(int collegeId, int labId, Student student) {

		College college = collegeRepository.findById(collegeId).get();

		Student s = new Student();
		List<Lab> lab = college.getLabs();

		List<Student> studentDetails = new ArrayList<Student>();
		studentDetails.add(s);

		for (Lab l : lab) {
			if (l.getLabId() == labId) {
				l.setStudents(studentDetails);
			}
		}

		return "student details are updated successfully";
	}
}
