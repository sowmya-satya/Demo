package com.mindtree.collegemanagement.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.collegemanagement.entity.College;
import com.mindtree.collegemanagement.entity.Student;
import com.mindtree.collegemanagement.service.CollegeService;

@RestController
@RequestMapping(path = "/college")
public class AppController {

	@Autowired
	private CollegeService collegeService;

	@PostMapping(path = "/addDetails")
	public ResponseEntity<Map<String, Object>> addDetails(@RequestBody College college) {
		Map<String, Object> response = new HashMap<String, Object>();
		response.put("Header", "Insertion of college along with lab and student details");
		response.put("Error", false);
		response.put("Body", collegeService.addDetails(college));
		response.put("HttpStatus", HttpStatus.OK);
		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);

	}

	@GetMapping(path = "/getLabsAStudentAssociatedWith/{studentId}")
	public ResponseEntity<Map<String, Object>> getLabDetailsOnStudentDetails(@PathVariable int studentId) {
		Map<String, Object> response = new HashMap<String, Object>();
		response.put("Header", "Labs details a student is associated with");
		response.put("Error", false);
		response.put("Body", collegeService.getLabDetailsOnStudentDetails(studentId));
		response.put("HttpStatus", HttpStatus.OK);
		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);

	}

	@GetMapping(path = "/getStudentDetailsForParticularlab/{labName}")
	public ResponseEntity<Map<String, Object>> getStudentDetailsForParticularLab(@PathVariable String labName) {
		Map<String, Object> response = new HashMap<String, Object>();
		response.put("Header", "Student Details for a Particular Lab");
		response.put("Error", false);
		response.put("Body", collegeService.getStudentDetailsForParticularLab(labName));
		response.put("HttpStatus", HttpStatus.OK);
		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);
	}

	@GetMapping(path = "/studentsRegisteredForMoreThan3Labs")
	public ResponseEntity<Map<String, Object>> getStudentDetailsRegisteredForMoreThan3Labs() throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		response.put("Header", "Student Details for a Particular Lab");
		response.put("Error", false);
		response.put("Body", collegeService.getStudentDetailsRegisteredForMoreThan3Labs());
		response.put("HttpStatus", HttpStatus.OK);
		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);
	}

	@PutMapping(path = "/updateStudent/{collegeId}/{labId}")
	public ResponseEntity<Map<String, Object>> updateDetails(@PathVariable int collegeId, @PathVariable int labId,
			@RequestBody Student student) {
		Map<String, Object> response = new HashMap<String, Object>();
		response.put("Header", "Student Details for a Particular Lab");
		response.put("Error", false);
		response.put("Body", collegeService.updateDetails(collegeId, labId, student));
		response.put("HttpStatus", HttpStatus.OK);
		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);
	}

}
