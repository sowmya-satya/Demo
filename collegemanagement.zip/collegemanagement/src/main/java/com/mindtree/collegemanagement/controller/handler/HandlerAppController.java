package com.mindtree.collegemanagement.controller.handler;

import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.mindtree.collegemanagement.controller.AppController;
import com.mindtree.collegemanagement.exception.ServiceException;

@RestControllerAdvice(assignableTypes = AppController.class)
public class HandlerAppController {
	@ExceptionHandler(ServiceException.class)
	public ResponseEntity<Map<String, Object>> ServiceExceptionHandler(Exception e, Throwable cause) {
		Map<String, Object> response = new LinkedHashMap<String, Object>();
		response.put("Header", "Exception");
		response.put("Error", true);
		response.put("body", e.getMessage());
		response.put("Httpstatus", HttpStatus.BAD_REQUEST);
		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.BAD_REQUEST);
	}
}
