package com.mindtree.collegemanagement.service;

import java.util.List;

import com.mindtree.collegemanagement.entity.College;
import com.mindtree.collegemanagement.entity.Lab;
import com.mindtree.collegemanagement.entity.Student;
import com.mindtree.collegemanagement.exception.ServiceException;

public interface CollegeService {

	/**
	 * @param college
	 * @return
	 */
	String addDetails(College college);

	/**
	 * @param studentId
	 * @return
	 */
	List<Lab> getLabDetailsOnStudentDetails(int studentId);

	/**
	 * @param labName
	 * @return
	 */
	List<Student> getStudentDetailsForParticularLab(String labName);

	/**
	 * @return
	 * @throws ServiceException
	 */
	List<Student> getStudentDetailsRegisteredForMoreThan3Labs() throws ServiceException;

	/**
	 * @param collegeId
	 * @param labId
	 * @param student
	 * @return
	 */
	String updateDetails(int collegeId, int labId, Student student);

}
