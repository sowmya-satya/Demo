package com.mindtree.collegemanagement.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Lab {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int labId;
	private String labName;
	@ManyToOne(cascade = CascadeType.PERSIST)
	private College college;

	@ManyToMany(cascade = { CascadeType.PERSIST, CascadeType.REFRESH })
	@JoinTable(name = "student_labs", joinColumns = @JoinColumn(name = "labId", referencedColumnName = "labId"), inverseJoinColumns = @JoinColumn(name = "studentId", referencedColumnName = "studentId"))
	private List<Student> students;

	public Lab() {
		super();
		
	}

	public Lab(int labId, String labName, College college, List<Student> students) {
		super();
		this.labId = labId;
		this.labName = labName;
		this.college = college;
		this.students = students;
	}

	public int getLabId() {
		return labId;
	}

	public void setLabId(int labId) {
		this.labId = labId;
	}

	public String getLabName() {
		return labName;
	}

	public void setLabName(String labName) {
		this.labName = labName;
	}

	@JsonIgnore
	public College getCollege() {
		return college;
	}

	public void setCollege(College college) {
		this.college = college;
	}

	public List<Student> getStudents() {
		return students;
	}

	public void setStudents(List<Student> students) {
		this.students = students;
	}

	@Override
	public String toString() {
		return "Lab [labId=" + labId + ", labName=" + labName + ", college=" + college + ", students=" + students + "]";
	}

}
