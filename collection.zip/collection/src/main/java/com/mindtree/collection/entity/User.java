package com.mindtree.collection.entity;

public class User implements Comparable<User> {

	private int userId;
	private String userName;
	private long phoneNo;

	public User() {
		super();
		// TODO Auto-generated constructor stub
	}

	public User(int userId, String userName, long phoneNo) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.phoneNo = phoneNo;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public long getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}

	@Override
	public String toString() {
		return "User [userId=" + userId + ", userName=" + userName + ", phoneNo=" + phoneNo + "]";
	}

	@Override
	public int compareTo(User user) {
		// TODO Auto-generated method
		if ((this.userName.compareToIgnoreCase(user.getUserName())) > 0) {
			return -1;
		} else {
			return 1;
		}
	}
}
