package com.mindtree.collection;

import java.io.ObjectInputStream.GetField;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

import com.mindtree.collection.entity.Building;
import com.mindtree.collection.entity.Room;
import com.mindtree.collection.entity.User;

public class App {
	public static void main(String[] args) {
		Set<User> users = new TreeSet<User>();
		Set<User> users1 = new TreeSet<User>();
		Set<User> users2 = new TreeSet<User>();

		Map<Room, Set<User>> rooms = new HashMap<>();
		Map<Room, Set<User>> rooms1 = new HashMap<>();

		Map<Building, Map<Room, Set<User>>> buildings = new HashMap<>();

		users.add(new User(1, "sai", 1234558));
		users.add(new User(2, "akash", 3261828));
		users.add(new User(3, "sandeep", 1234567));

		users1.add(new User(4, "komala", 2345678));
		users1.add(new User(5, "sarath", 1234567));

		users2.add(new User(6, "amar", 234567));
		users2.add(new User(7, "rahul", 1234567));

		rooms.put(new Room(1, "bahada"), users);
		rooms.put(new Room(2, "mahua"), users1);

		rooms1.put(new Room(3, "amla"), users2);

		buildings.put(new Building(1, "GLC"), rooms);
		buildings.put(new Building(2, "SDB"), rooms1);

		buildings.entrySet().forEach(i -> {
			System.out.println("Building:");
			System.out.println(i.getKey().getBuildingName());
			i.getValue().entrySet().forEach(j -> {
				System.out.println(j.getKey().getRoomName());
				j.getValue().forEach(k -> {
					System.out.println(k.getUserName() + ":" + k.getPhoneNo());
				});
			});
		});
	}
}
