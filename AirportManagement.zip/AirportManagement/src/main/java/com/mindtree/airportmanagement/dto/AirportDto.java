package com.mindtree.airportmanagement.dto;

import java.util.Set;

public class AirportDto {

	private int airportId;

	private String airportName;

	private Set<FlightDto> flightDtolist;

	public AirportDto() {
		super();
	}

	public AirportDto(int airportId, String airportName, Set<FlightDto> flightDtolist) {
		super();
		this.airportId = airportId;
		this.airportName = airportName;
		this.flightDtolist = flightDtolist;
	}

	public int getAirportId() {
		return airportId;
	}

	public void setAirportId(int airportId) {
		this.airportId = airportId;
	}

	public String getAirportName() {
		return airportName;
	}

	public void setAirportName(String airportName) {
		this.airportName = airportName;
	}

	public Set<FlightDto> getFlightDtolist() {
		return flightDtolist;
	}

	public void setFlightDtolist(Set<FlightDto> flightDtolist) {
		this.flightDtolist = flightDtolist;
	}

	@Override
	public String toString() {
		return "AirportDto [airportId=" + airportId + ", airportName=" + airportName + ", flightDtolist="
				+ flightDtolist + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((flightDtolist == null) ? 0 : flightDtolist.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AirportDto other = (AirportDto) obj;
		if (flightDtolist == null) {
			if (other.flightDtolist != null)
				return false;
		} else if (!flightDtolist.equals(other.flightDtolist))
			return false;
		return true;
	}

}
