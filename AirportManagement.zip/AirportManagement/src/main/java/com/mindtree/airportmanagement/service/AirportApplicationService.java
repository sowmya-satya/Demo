package com.mindtree.airportmanagement.service;

import java.util.List;

import com.mindtree.airportmanagement.dto.AirportDto;
import com.mindtree.airportmanagement.dto.FlightDto;
import com.mindtree.airportmanagement.dto.PassengerDto;
import com.mindtree.airportmanagement.entity.Passenger;
import com.mindtree.airportmanagement.exception.FlightServiceException;

public interface AirportApplicationService {

	/**
	 * @param airportDto
	 * @return String
	 */
	
	public String insertAirportDetailsToDB(AirportDto airportDto);

	/**
	 * @param flightDto
	 * @param airportName
	 * @return
	 */
	
	public String insertFlightDetailsToDB(FlightDto flightDto, String airportName);

	/**
	 * @param passengerDto
	 * @param flightName 
	 * @return String
	 */
	
	public String insertPassengerDetailsToDB(PassengerDto passengerDto, String flightName);

	/**
	 * @param passengerDto
	 * @param flightId
	 * @return
	 * @throws FlightServiceException 
	 */
	
	public Passenger updatePassengerDetailsByAgeToDB(PassengerDto passengerDto, int flightId) throws FlightServiceException;

	/**
	 * @param flightId
	 * @return
	 */
	
	public List<PassengerDto> getPassengersByFlightId(int flightId);

}
