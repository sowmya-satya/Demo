package com.mindtree.airportmanagement.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.airportmanagement.dto.AirportDto;
import com.mindtree.airportmanagement.dto.FlightDto;
import com.mindtree.airportmanagement.dto.PassengerDto;
import com.mindtree.airportmanagement.exception.FlightServiceException;
import com.mindtree.airportmanagement.service.AirportApplicationService;

@RestController
public class AirportApplicationController {

	@Autowired
	private AirportApplicationService airportService;

	@PostMapping("/airport")
	public ResponseEntity<Map<String, Object>> insertAirportDetails(@RequestBody AirportDto airportDto) {
		Map<String, Object> response = new HashMap<String, Object>();
		response.put("Header", "Airport Application");
		response.put("Error", false);
		response.put("Body", airportService.insertAirportDetailsToDB(airportDto));
		response.put("status", HttpStatus.ACCEPTED);

		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.ACCEPTED);
	}

	@PostMapping("/flight/{airportName}")
	public ResponseEntity<Map<String, Object>> insertFlightDetails(@RequestBody FlightDto flightDto,
			@PathVariable String airportName) {
		Map<String, Object> response = new HashMap<String, Object>();
		response.put("Header", "Airport Application");
		response.put("Error", false);
		response.put("Body", airportService.insertFlightDetailsToDB(flightDto, airportName));
		response.put("status", HttpStatus.ACCEPTED);

		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.ACCEPTED);
	}

	@PostMapping("/passenger/{flightName}")
	public ResponseEntity<Map<String, Object>> insertPassengerDetails(@RequestBody PassengerDto passengerDto,
			@PathVariable String flightName) {
		Map<String, Object> response = new HashMap<String, Object>();
		response.put("Header", "Airport Application");
		response.put("Error", false);
		response.put("Body", airportService.insertPassengerDetailsToDB(passengerDto, flightName));
		response.put("status", HttpStatus.ACCEPTED);

		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.ACCEPTED);
	}

	@PostMapping("passengers/{flightId}")
	public ResponseEntity<Map<String, Object>> updatePassengerDetailsByAge( PassengerDto passengerDto,
			@PathVariable int flightId) throws FlightServiceException {
		Map<String, Object> response = new HashMap<String, Object>();
		response.put("Header", "Airport Application");
		response.put("Error", false);
		response.put("Body", airportService.updatePassengerDetailsByAgeToDB(passengerDto, flightId));
		response.put("status", HttpStatus.OK);
		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);
	}

	@GetMapping("passenger/{flightId}")
	public ResponseEntity<Map<String, Object>> getPassengersByFlightId(@PathVariable int flightId) {
		Map<String, Object> response = new HashMap<String, Object>();
		response.put("Header", "Airport Application");
		response.put("Error", false);
		response.put("Body", airportService.getPassengersByFlightId(flightId));
		response.put("status", HttpStatus.FOUND);
		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.FOUND);
	}

}
