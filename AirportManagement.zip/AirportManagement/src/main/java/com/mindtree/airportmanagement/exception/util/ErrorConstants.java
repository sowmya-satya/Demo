package com.mindtree.airportmanagement.exception.util;

public class ErrorConstants {

	public static final String FLIGHTNOTFOUNDEXCEPTION = "flight you are trying is not available.. Try for another Flight";
}
