package com.mindtree.airportmanagement.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

public class PassengerDto implements Comparable<PassengerDto> {

	private int passengerId;

	private String passengerName;

	private int age;

	private double ticketCost;
	
	@JsonIgnoreProperties(value = "passengerDtoLists")
	private FlightDto flightDtoList;

	public PassengerDto() {
		super();
		
	}

	public PassengerDto(int passengerId, String passengerName, int age, double ticketCost, FlightDto flightDtoList) {
		super();
		this.passengerId = passengerId;
		this.passengerName = passengerName;
		this.age = age;
		this.ticketCost = ticketCost;
		this.flightDtoList = flightDtoList;
	}

	public int getPassengerId() {
		return passengerId;
	}

	public void setPassengerId(int passengerId) {
		this.passengerId = passengerId;
	}

	public String getPassengerName() {
		return passengerName;
	}

	public void setPassengerName(String passengerName) {
		this.passengerName = passengerName;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public double getTicketCost() {
		return ticketCost;
	}

	public void setTicketCost(double ticketCost) {
		this.ticketCost = ticketCost;
	}

	public FlightDto getFlightDtoList() {
		return flightDtoList;
	}

	public void setFlightDtoList(FlightDto flightDtoList) {
		this.flightDtoList = flightDtoList;
	}

	@Override
	public String toString() {
		return "PassengerDto [passengerId=" + passengerId + ", passengerName=" + passengerName + ", age=" + age
				+ ", ticketCost=" + ticketCost + ", flightDtoList=" + flightDtoList + "]";
	}

	@Override
	public int compareTo(PassengerDto passengerDto) {
		int age = passengerDto.getAge()-this.getAge();
		if(age==0) {
			return (int) (passengerDto.getTicketCost()-this.getTicketCost());
		}
		else  if(passengerDto.getPassengerName().compareTo(this.getPassengerName())==0){
			return age;
		}
		return age;
	}
	
	
}
