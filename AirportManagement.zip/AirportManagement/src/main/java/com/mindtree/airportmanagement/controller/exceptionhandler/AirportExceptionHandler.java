package com.mindtree.airportmanagement.controller.exceptionhandler;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.mindtree.airportmanagement.controller.AirportApplicationController;
import com.mindtree.airportmanagement.exception.FlightServiceException;

@RestControllerAdvice(assignableTypes = AirportApplicationController.class)
public class AirportExceptionHandler {

	@ExceptionHandler(FlightServiceException.class)
	public ResponseEntity<Map<String, Object>> serviceException (Exception e, Throwable clause) {
		Map<String, Object> response = new HashMap<String, Object>();
		response.put("Header", "Channel Error");
		response.put("Error", true);
		response.put("Message",e.getMessage() );
		response.put("Status ", HttpStatus.BAD_REQUEST);
		
		return new ResponseEntity<Map<String,Object>>(response,HttpStatus.BAD_REQUEST);
		
	}
}
