package com.mindtree.airportmanagement.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

public class FlightDto {

	private int flightId;

	private String flightName;

	private double ticketPrice;
	
	@JsonIgnoreProperties(value = "flightDtoList")
	private List<PassengerDto> passengerDtoLists;

	@JsonIgnoreProperties(value = "airportDto")
	private AirportDto airportDto;

	public FlightDto() {
		super();

	}

	public FlightDto(int flightId, String flightName, double ticketPrice, List<PassengerDto> passengerDtoLists,
			AirportDto airportDto) {
		super();
		this.flightId = flightId;
		this.flightName = flightName;
		this.ticketPrice = ticketPrice;
		this.passengerDtoLists = passengerDtoLists;
		this.airportDto = airportDto;
	}

	public int getFlightId() {
		return flightId;
	}

	public void setFlightId(int flightId) {
		this.flightId = flightId;
	}

	public String getFlightName() {
		return flightName;
	}

	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}

	public double getTicketPrice() {
		return ticketPrice;
	}

	public void setTicketPrice(double ticketPrice) {
		this.ticketPrice = ticketPrice;
	}

	public List<PassengerDto> getPassengerDtoLists() {
		return passengerDtoLists;
	}

	public void setPassengerDtoLists(List<PassengerDto> passengerDtoLists) {
		this.passengerDtoLists = passengerDtoLists;
	}

	public AirportDto getAirportDto() {
		return airportDto;
	}

	public void setAirportDto(AirportDto airportDto) {
		this.airportDto = airportDto;
	}

	@Override
	public String toString() {
		return "FlightDto [flightId=" + flightId + ", flightName=" + flightName + ", ticketPrice=" + ticketPrice
				+ ", passengerDtoLists=" + passengerDtoLists + ", airportDto=" + airportDto + "]";
	}

}
