package com.mindtree.airportmanagement.exception;

public class FlightServiceException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public FlightServiceException() {
		super();


	}

	public FlightServiceException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);


	}

	public FlightServiceException(String arg0, Throwable arg1) {
		super(arg0, arg1);


	}

	public FlightServiceException(String arg0) {
		super(arg0);


	}

	public FlightServiceException(Throwable arg0) {
		super(arg0);
		
	}

}
