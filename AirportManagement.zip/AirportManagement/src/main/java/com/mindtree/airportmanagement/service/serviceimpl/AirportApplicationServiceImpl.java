package com.mindtree.airportmanagement.service.serviceimpl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.airportmanagement.dto.AirportDto;
import com.mindtree.airportmanagement.dto.FlightDto;
import com.mindtree.airportmanagement.dto.PassengerDto;
import com.mindtree.airportmanagement.entity.Airport;
import com.mindtree.airportmanagement.entity.Flight;
import com.mindtree.airportmanagement.entity.Passenger;
import com.mindtree.airportmanagement.exception.FlightServiceException;
import com.mindtree.airportmanagement.exception.util.ErrorConstants;
import com.mindtree.airportmanagement.repository.AirportRepository;
import com.mindtree.airportmanagement.repository.FlightRepository;
import com.mindtree.airportmanagement.repository.PassengerRepository;
import com.mindtree.airportmanagement.service.AirportApplicationService;

@Service
public class AirportApplicationServiceImpl implements AirportApplicationService {

	@Autowired
	private AirportRepository airportRepository;

	@Autowired
	private FlightRepository flightRepository;

	@Autowired
	private PassengerRepository passengerRepository;

	private ModelMapper mapper = new ModelMapper();

	@Override
	public String insertAirportDetailsToDB(AirportDto airportDto) {
		Airport airport = mapper.map(airportDto, Airport.class);
		airportRepository.save(airport);
		return "airport inserted ";
	}

	@Override
	public String insertFlightDetailsToDB(FlightDto flightDto, String airportName) {
		Flight flight = mapper.map(flightDto, Flight.class);
		Airport airport = airportRepository.findByAirportName(airportName);
		flight.setAirport(airport);
		flightRepository.saveAndFlush(flight);
		return "flight inserted";
	}

	@Override
	public String insertPassengerDetailsToDB(PassengerDto passengerDto, String flightName) {
		Passenger passenger = mapper.map(passengerDto, Passenger.class);
		Flight flight = flightRepository.findByFlightName(flightName);
		passenger.setFlight(flight);
		passengerRepository.saveAndFlush(passenger);
		return "passenger inserted";
	}

	@Override
	public Passenger updatePassengerDetailsByAgeToDB(PassengerDto passengerDto, int flightId) throws FlightServiceException {
		
		Passenger passenger = mapper.map(passengerDto, Passenger.class);
		Flight flight = passenger.getFlight();
			flightRepository.findById(flightId).orElseThrow(()->new FlightServiceException(ErrorConstants.FLIGHTNOTFOUNDEXCEPTION));
			int age = passenger.getAge();
			double ticketExpense = passenger.getTicketCost();
			double expense = 0.0;		
			if(passenger.getAge()>60) {
				passenger.setAge(age);
				expense = ticketExpense-(ticketExpense*20)/100;
				passenger.setTicketCost(expense);
				passenger.setFlight(flight);
				passengerRepository.save(passenger);					
			}else {
				passenger.setFlight(flight);
				passengerRepository.save(passenger);
			}
		
		return passengerRepository.save(passenger);

	}

	@Override
	public List<PassengerDto> getPassengersByFlightId(int flightId) {
		Flight flight = flightRepository.findById(flightId).get();
		List<PassengerDto> passengerDtoList = new ArrayList<PassengerDto>();
		List<Passenger> passengers = flight.getPassengers();

		for (Passenger passenger : passengers) {
			PassengerDto passengerDto = mapper.map(passenger, PassengerDto.class);
			passengerDtoList.add(passengerDto);
		}
		Collections.sort(passengerDtoList);
		return passengerDtoList;
	}

}
