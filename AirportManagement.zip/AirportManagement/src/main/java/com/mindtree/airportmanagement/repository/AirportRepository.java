package com.mindtree.airportmanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mindtree.airportmanagement.entity.Airport;

@Repository
public interface AirportRepository extends JpaRepository<Airport, Integer>{

	/**
	 * @param airportName
	 * @return
	 */
	
	public Airport findByAirportName(String airportName);

}
