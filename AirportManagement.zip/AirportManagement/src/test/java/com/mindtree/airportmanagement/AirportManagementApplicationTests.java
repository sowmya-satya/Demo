package com.mindtree.airportmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AirportManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
